import React, { Component } from "react";

class DeleteButton extends Component {
  render() {
    return (
      <div className="button-wrapper">
        <button
          className="delete-button"
          onClick={() => this.props.deleteButton(this.props.position)}
        >
          Delete Quote
        </button>
      </div>
    );
  }
}

export default DeleteButton;

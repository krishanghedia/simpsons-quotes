import React, { Component } from "react";

class Direction extends Component {
  render() {
    return <p>Direction: {this.props.direction}</p>;
  }
}

export default Direction;
